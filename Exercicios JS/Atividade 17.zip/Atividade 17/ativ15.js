var numero1, numero2, numero3, maior;

numero1 = 40
numero2 = 45
numero3 = 10
maior = numero3

if (numero1 > maior){
maior = numero1
}
if (numero2 > maior){
maior = numero2
}

console.log ("O maior número é:", maior)