var quantidadelatao, zinco, cobre;

quantidadelatao = 10
zinco = quantidadelatao * 0.7
cobre = quantidadelatao * 0.3

console.log ("Quantidade de latão:",quantidadelatao, "Zinco:", zinco, "Cobre:", cobre)