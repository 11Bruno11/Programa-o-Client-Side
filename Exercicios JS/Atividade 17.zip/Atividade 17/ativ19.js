var numero1, numero2, numero3, numero4, soma;

numero1 = 2
numero2 = 1
numero3 = 2
numero4 = 4
soma = 0

if (numero1 % 2 == 0) {
    soma = soma + numero1
}
if (numero2 % 2 == 0) {
    soma = soma + numero2
}
if (numero3 % 2 == 0) {
    soma = soma + numero3
}
if (numero4 % 2 == 0) {
    soma = soma + numero4
}

console.log("A soma dos números é:",soma)
