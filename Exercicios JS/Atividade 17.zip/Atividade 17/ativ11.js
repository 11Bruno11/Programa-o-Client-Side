var precofabrica, precoimposto, precovendedor;

precofabrica = 30000;

precoimposto = precofabrica * (45 / 100) + precofabrica

precovendedor = precoimposto * (12 / 100)

console.log ("Preço de Fabrica:", precofabrica, "Preço com os impostos:", precoimposto, "Comissão do Vendedor:", precovendedor)