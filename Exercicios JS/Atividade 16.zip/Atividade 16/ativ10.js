var a = 1;
var b = 4;

if (a == b) {
    console.log("As duas letras são iguais")
    
} else  if (a > b) {
    console.log("Letra A é maior")
} else {
    console.log("Letra B é maior")
}