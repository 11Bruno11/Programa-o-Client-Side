var a = 3;
var b = 8.9;

var soma = a + b;

var multi = a * b;

var quociente = a / b;

console.log ("Soma=", soma, "Multiplicação=", multi, "Quociente=", quociente)