var numero = 10
console.log(numero + 1)