var a = 10
var b = 16
var c = 30

var soma = b + c

if (soma > a) {
    console.log("A soma dos itens 2 e 3 é maior que o 1 número.")
} else {
    console.log("A soma dos itens 2 e 3 é menor que o 1 número.")
}