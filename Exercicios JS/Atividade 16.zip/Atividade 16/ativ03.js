var DF, CD, PC, QC, resul;

DF = 365;
CD = 4;
PC = 10;
QC = 20;

resul = (DF * CD) / QC * 12;

console.log(resul);