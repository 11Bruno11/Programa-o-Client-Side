var A = 5;
var B = 10;
var C = 20;

var D = A * (B**2);

var E = (2*A) * B * C;

var area = 2 * D + E;

console.log(area)