var a, b, resul, resto;

a = 18;
b = 8;

resul = a / b;
resto = a % b;

console.log ("Resul=", resul, "Resto=", resto)