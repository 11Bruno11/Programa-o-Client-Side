var NI = "Lucas";

var NC = "Bruno";

if (NI == NC) {
    console.log("Nome correto")
} else { 
    console.log("Nome Incorreto")
}