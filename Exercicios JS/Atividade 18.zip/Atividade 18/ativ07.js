var diametro, comprimento, area, pi, raio;

pi = 3.14
raio = 6

diametro = 2 * raio
comprimento = 2 * pi * raio
area = pi * raio * raio

console.log ("Diametro:", diametro, "Comprimento:", comprimento, "Area:", area)