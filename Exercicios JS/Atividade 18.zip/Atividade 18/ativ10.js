var nome, sexo;

nome = Bruno
sexo = Masculino

if (sexo = Masculino) {
    console.log("Nome:", nome, "Sexo:", sexo, "Homem.")
}
else if (sexo = Feminino) {
    console.log("Nome:", nome, "Sexo:", sexo, "Mulher.")
}