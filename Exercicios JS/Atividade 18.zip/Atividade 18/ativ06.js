var numero;

numero = 3

if (numero % 2 || numero == 0){
    console.log("Impar")
} 
else {
    console.log("Par")
}