var num1, num2, total;

num1 = 0
num2 = 10

if (num1 == 0){
    console.log("Não existe divisão com zero")
}
else if (total = num1 / num2){
    console.log("O valor da sua divisão é:", total)
}