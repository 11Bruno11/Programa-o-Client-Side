var idade;

idade = 61

if (idade < 18){
    console.log("Menor de Idade")
}
else if (idade >= 18 && idade <= 60) {
    console.log("Maior de Idade")
}
else if (idade > 60) {
    console.log("Idoso")
}