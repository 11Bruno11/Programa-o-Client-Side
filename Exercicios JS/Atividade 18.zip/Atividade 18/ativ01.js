var precokilo, kilo, total;

precokilo = 12
kilo = 4
total = kilo * precokilo

console.log ("O preço do prato é de", total, "Reais.")