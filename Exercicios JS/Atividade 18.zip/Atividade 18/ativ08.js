var x, y, z;

x = 10
y = 12
console.log ("X:", x, "Y:", y)
z = x
x = y
y = z
console.log ("X:", x, "Y:", y)