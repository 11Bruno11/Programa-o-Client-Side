var num1 = 10

if (num1 >= 100 && num1 <= 200) {
    console.log("Seu número está entre 100 e 200")
}
else {
    console.log("Seu número não está entre 100 e 200.")
}