var kilo, gramas, total;

kilo = 65
gramas = 1000
total = kilo * gramas

console.log("O seu peso em gramas, é de:", total)